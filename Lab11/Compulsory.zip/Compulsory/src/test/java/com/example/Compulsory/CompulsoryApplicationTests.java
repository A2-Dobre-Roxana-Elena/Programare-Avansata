package com.example.Compulsory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompulsoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
