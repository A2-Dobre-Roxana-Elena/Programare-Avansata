package com.example.Compulsory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompulsoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompulsoryApplication.class, args);
	}

}
